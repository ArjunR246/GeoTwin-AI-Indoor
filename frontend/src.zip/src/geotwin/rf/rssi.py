from geotwin.rf.ap import AccessPoint
from geotwin.rf.propagation import calculate_propagation_loss


def calculate_rssi(
    ap: AccessPoint,
    distance_m: float,
    receiver_gain_dbi: float = 0.0,
    reference_distance_m: float = 1.0,
    path_loss_exponent: float = 3.0,
    wall_material: str = "concrete",
    number_of_walls: int = 0,
    obstacle_loss_db: float = 0.0,
) -> float:
    """
    Calculate received signal strength (RSSI) in dBm.

    RSSI = Pt + Gt + Gr - Ltotal
    """

    if receiver_gain_dbi < -20:
        raise ValueError(
            "Receiver antenna gain is unrealistically low."
        )

    propagation = calculate_propagation_loss(
        frequency_hz=ap.frequency_hz,
        distance_m=distance_m,
        reference_distance_m=reference_distance_m,
        path_loss_exponent=path_loss_exponent,
        wall_material=wall_material,
        number_of_walls=number_of_walls,
        obstacle_loss_db=obstacle_loss_db,
    )

    return (
        ap.tx_power_dbm
        + ap.antenna_gain_dbi
        + receiver_gain_dbi
        - propagation.total_loss_db
    )

