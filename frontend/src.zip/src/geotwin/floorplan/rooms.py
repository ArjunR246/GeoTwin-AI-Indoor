from dataclasses import dataclass

import cv2
import numpy as np


@dataclass(frozen=True)
class Room:
    """Represents an enclosed region detected in a floor plan."""

    id: str
    polygon: tuple[tuple[int, int], ...]
    area: float
    centroid: tuple[float, float]
    bounding_box: tuple[int, int, int, int]
    aspect_ratio: float

    @property
    def width(self) -> int:
        """Return room bounding-box width."""
        return self.bounding_box[2]

    @property
    def height(self) -> int:
        """Return room bounding-box height."""
        return self.bounding_box[3]


def _validate_binary(binary: np.ndarray) -> None:
    """Validate the floor-plan image."""
    if not isinstance(binary, np.ndarray):
        raise TypeError("Binary floor-plan image must be a NumPy array.")

    if binary.size == 0:
        raise ValueError("Binary floor-plan image is empty.")

    if binary.ndim != 2:
        raise ValueError("Binary floor-plan image must be single-channel.")


def _find_enclosed_regions(binary: np.ndarray) -> np.ndarray:
    """
    Find enclosed white regions in a floor plan.

    The floor-plan walls are expected to be represented as dark
    structures against a light background.
    """
    # Convert to a clean binary representation.
    _, thresholded = cv2.threshold(
        binary,
        127,
        255,
        cv2.THRESH_BINARY,
    )

    # Flood-fill the exterior background.
    flood = thresholded.copy()

    mask = np.zeros(
        (flood.shape[0] + 2, flood.shape[1] + 2),
        dtype=np.uint8,
    )

    cv2.floodFill(
        flood,
        mask,
        (0, 0),
        128,
    )

    # Original white pixels that were NOT reached from the exterior
    # are enclosed regions.
    enclosed = np.where(
        (thresholded == 255) & (flood != 128),
        255,
        0,
    ).astype(np.uint8)

    return enclosed


def _contour_to_room(
    contour: np.ndarray,
    room_index: int,
) -> Room | None:
    """Convert a contour into a Room object."""
    area = float(cv2.contourArea(contour))

    if area <= 0:
        return None

    perimeter = cv2.arcLength(contour, True)

    # Approximate the contour to reduce unnecessary points.
    epsilon = 0.01 * perimeter

    polygon = cv2.approxPolyDP(
        contour,
        epsilon,
        True,
    )

    if len(polygon) < 3:
        return None

    points = tuple(
        (int(point[0][0]), int(point[0][1]))
        for point in polygon
    )

    x, y, width, height = cv2.boundingRect(contour)

    if width <= 0 or height <= 0:
        return None

    moments = cv2.moments(contour)

    if moments["m00"] != 0:
        centroid_x = moments["m10"] / moments["m00"]
        centroid_y = moments["m01"] / moments["m00"]
    else:
        centroid_x = x + width / 2
        centroid_y = y + height / 2

    aspect_ratio = width / height

    return Room(
        id=f"room_{room_index}",
        polygon=points,
        area=area,
        centroid=(float(centroid_x), float(centroid_y)),
        bounding_box=(x, y, width, height),
        aspect_ratio=float(aspect_ratio),
    )


def detect_rooms(
    binary: np.ndarray,
    min_area: float = 1000.0,
    max_area_ratio: float = 0.95,
) -> list[Room]:
    """
    Detect enclosed regions that can represent rooms.

    Args:
        binary:
            Preprocessed binary floor-plan image.
        min_area:
            Minimum enclosed-region area in pixels.
        max_area_ratio:
            Maximum allowed region area as a fraction of the
            complete floor-plan image.

    Returns:
        List of detected Room objects.
    """
    _validate_binary(binary)

    image_area = float(binary.shape[0] * binary.shape[1])
    max_area = image_area * max_area_ratio

    enclosed = _find_enclosed_regions(binary)

    contours, _ = cv2.findContours(
        enclosed,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE,
    )

    rooms: list[Room] = []

    for contour in contours:
        area = float(cv2.contourArea(contour))

        if area < min_area:
            continue

        if area > max_area:
            continue

        room = _contour_to_room(
            contour,
            len(rooms) + 1,
        )

        if room is not None:
            rooms.append(room)

    # Sort top-to-bottom and left-to-right so room IDs are stable.
    rooms.sort(
        key=lambda room: (
            round(room.centroid[1] / 20),
            room.centroid[0],
        )
    )

    # Reassign IDs after sorting.
    normalized_rooms: list[Room] = []

    for index, room in enumerate(rooms, start=1):
        normalized_rooms.append(
            Room(
                id=f"room_{index}",
                polygon=room.polygon,
                area=room.area,
                centroid=room.centroid,
                bounding_box=room.bounding_box,
                aspect_ratio=room.aspect_ratio,
            )
        )

    return normalized_rooms